// The world outside Herdr: code editors, Finder/Explorer. This computer only: a
// path on another machine means nothing to an app here.
import { appHome, exec, knownAgents, readTextFile, run, setShared, shared, window } from "herdr";
import { EDITORS } from "../files/model.js";
import {
  pickDetectEditors,
  pickOpenInEditor,
  pickOpenWithDefault,
  pickReveal,
  revealError,
} from "../files/shell.js";

const FOUND = "better-files.editors";
const ERROR = "better-files.error";

export const foundEditors = () => shared(FOUND) ?? [];

// macOS entries are known by app ID, Windows ones by their exe.
export const editorId = (e) => e.bundle ?? e.exe;

export const outsideMethods = {
  // macOS: one lookup per app ID, done once: Spotlight knows apps wherever they're
  // installed. Windows: one PowerShell process probes App Paths, PATH, and well-known
  // dirs for every candidate; first hit wins. Both store { name, bundle } or
  // { name, exe } entries in shared state.
  findEditors(cx, extra = []) {
    const pick = pickDetectEditors(EDITORS, extra, window()?.platform);
    cx.spawn(async (cx) => {
      const found = [];
      if (pick.kind === "single") {
        const r = await exec(pick.program, pick.args, {}).catch(() => null);
        const fields = r?.code === 0 ? r.stdout.split("\0") : [];
        for (let i = 0; i + 1 < fields.length; i += 2) found.push({ name: fields[i], exe: fields[i + 1] });
      } else {
        for (const probe of pick.probes) {
          const r = await exec(probe.program, probe.args, {}).catch(() => null);
          if (r?.code === 0 && r.stdout.trim()) found.push(probe.editor);
        }
      }
      setShared(FOUND, found);
      cx.notify();
    });
  },

  // Show diff is only offered where Better Changes can answer it.
  findBetterChanges(cx) {
    cx.spawn(async (cx) => {
      const manifest = await readTextFile(`${appHome()}/mods/better-changes/mod.json`).catch(
        () => null,
      );
      setShared("better-files.has-changes", Boolean(manifest));
      cx.notify();
    });
  },

  findNewAgents(on, cx) {
    cx.spawn(async (cx) => {
      try {
        const known = await knownAgents({ on: on ?? null });
        setShared(
          "better-files.new-agents",
          known.filter((a) => a.installed).map((a) => ({ key: a.key, name: a.name, run: a.run })),
        );
      } catch {
        setShared("better-files.new-agents", []);
      }
      cx.notify();
    });
  },

  // Runs the platform's open command; a failure lands in the shared error slot the
  // sidebar renders as a message.
  async outside(cmd, what) {
    const r = await exec(cmd.program, cmd.args, {}).catch((e) => ({ code: 1, stderr: String(e) }));
    if (r.code !== 0) setShared(ERROR, `Could not ${what}: ${r.stderr?.trim() || "it failed"}`);
    else setShared(ERROR, null);
  },

  openInEditor(editor, path) {
    return this.outside(pickOpenInEditor(editor, path, window()?.platform), `open it in ${editor.name}`);
  },

  openWithDefault(path) {
    return this.outside(pickOpenWithDefault(path, window()?.platform), "open it");
  },

  reveal(path) {
    const platform = window()?.platform;
    return this.outside(pickReveal(path, platform), revealError(platform));
  },

  // Edit: a terminal running the person's chosen editor, in the same spot as the viewer
  // rather than beside it. It's actually a split, then zoomed so it fills the tab and
  // hides the viewer; when the editor's program exits, Herdr closes its pane on its own,
  // the zoom ends with it, and the viewer is what's left, showing the file again.
  editInTerminal(path) {
    const words = (this.terminalEditor || "nano").trim().split(/\s+/).filter(Boolean);
    if (!words.length) return;
    run("pane.split", { direction: "right", argv: [...words, path] });
    // Zoomed in the same tick as the split, with no pane named: a new split takes the
    // keyboard at once, so this is the pane that command reaches. Firing both together,
    // rather than a tick apart, leaves Herdr's own transition to show as one motion
    // instead of a split appearing and then jumping to full size a moment later.
    run("pane.zoom", {});
  },
};
