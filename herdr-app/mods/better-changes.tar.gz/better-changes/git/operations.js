// Branches and the usual remote operations: switch, create, fetch, pull, push. Each runs
// Git on the repository's own machine and then rereads it. They share the index actions'
// `busy` flag, so only one thing changes the repository at a time.
import { exec, setShared, window } from "herdr";
import { InputState } from "gpui-base";
import { readBranches } from "./reads.js";

const LOCAL_MS = 30000;
const NETWORK_MS = 120000;
// There's no terminal to answer with: a credential prompt, a merge message editor, or an
// editor for a pull's merge commit would wait forever. These make Git fail or carry on instead.
const NO_PROMPTS = ["GIT_TERMINAL_PROMPT=0", "GIT_MERGE_AUTOEDIT=no", "GIT_EDITOR=true"];

// What a failed command said, trimmed to something that fits a note.
function reason(result) {
  const text = (result.stderr || result.stdout || "").trim();
  if (!text) return `git exited with ${result.code}`;
  const lines = text.split("\n").filter(Boolean);
  const keep = lines.filter((l) => !/^hint:/i.test(l));
  return (keep.length ? keep : lines).slice(0, 3).join(" ");
}

export const operationMethods = {
  initBranchBar(cx) {
    this.branchMenuOpen = false;
    this.branchMenuFocus = cx.focus_handle();
    this.branches = null;
    this.sync = null;
    this.branchFilter = InputState.new({ placeholder: "Switch or create branch…" });
    this.branchFilter.on("change", (_e, cx) => cx.notify());
    this.branchFilter.on("submit", (_e, cx) => this.branchEnter(cx));
  },

  // `env` is how the no-prompt variables get to Git. Windows has none, and its Git can
  // ask through its own credential window.
  gitRaw(args, { network = false } = {}, root = this.root, on = this.on) {
    const unix = on ? true : window()?.platform !== "windows";
    const [program, ...head] = unix ? ["env", ...NO_PROMPTS, "git"] : ["git"];
    return exec(program, [...head, ...args], {
      cwd: root,
      on,
      timeout: network ? NETWORK_MS : LOCAL_MS,
    });
  },

  loadBranches(cx) {
    if (!this.root || !this.branchFilter) return;
    const context = this.context;
    cx.spawn(async (cx) => {
      try {
        const branches = await readBranches((args) => this.git(args));
        if (this.isCurrent(context)) this.branches = branches;
      } catch {
        // The menu shows what it last had; the status poll will say if Git is gone.
      }
      cx.notify();
    });
  },

  openBranchMenu(open, cx) {
    this.branchMenuOpen = open;
    if (open) {
      this.branchFilter.set_value("");
      this.loadBranches(cx);
      cx.timer.after(50, () => this.branchFilter.focus());
    }
    cx.notify();
  },

  // Runs `work(run)`, where `run(args, {network})` throws Git's reason on failure. Afterwards
  // the repository is read again, whatever happened.
  runOperation(operation, failure, work, cx) {
    if (!this.root || this.busy || this.contextKey() !== this.context) return;
    const { root, on, context } = this;
    this.busy = true;
    this.operation = operation;
    this.note = null;
    this.branchMenuOpen = false;
    cx.notify();
    cx.spawn(async (cx) => {
      const run = async (args, options) => {
        const result = await this.gitRaw(args, options, root, on);
        if (result.code !== 0) throw Error(reason(result));
        return result.stdout;
      };
      try {
        await work(run);
        this.reload = Date.now();
        setShared("better-changes.reload", { root, on: on ?? null, at: this.reload });
      } catch (error) {
        if (this.isCurrent(context)) this.note = `${failure}: ${error.message}`;
      } finally {
        this.busy = false;
        this.operation = null;
        this.refresh(cx);
        if (this.tab === "commit") this.loadCommits(cx);
        this.loadBranches(cx);
        cx.notify();
      }
    });
  },

  fetchAll(cx) {
    this.runOperation("fetch", "Fetch failed", (run) => run(["fetch", "--all", "--prune"], { network: true }), cx);
  },

  pull(cx) {
    if (this.sync && !this.sync.upstream) {
      this.note = "Pull failed: this branch has no upstream. Push it first to publish it.";
      cx.notify();
      return;
    }
    this.runOperation("pull", "Pull failed", (run) => run(["pull"], { network: true }), cx);
  },

  // A branch that was never pushed is published to its first remote, with tracking set up.
  push(cx) {
    const tracked = Boolean(this.sync?.upstream);
    this.runOperation(
      "push",
      "Push failed",
      async (run) => {
        if (tracked) return run(["push"], { network: true });
        const remotes = (await run(["remote"])).split("\n").filter(Boolean);
        if (!remotes.length) throw Error("this repository has no remote.");
        const remote = remotes.includes("origin") ? "origin" : remotes[0];
        return run(["push", "-u", remote, "HEAD"], { network: true });
      },
      cx,
    );
  },

  switchBranch(name, cx) {
    if (this.branch === name) return this.openBranchMenu(false, cx);
    this.runOperation("switch", "Cannot switch branch", (run) => run(["checkout", name, "--"]), cx);
  },

  // A branch that only exists on a remote becomes a local one that tracks it.
  switchRemote(ref, cx) {
    this.runOperation("switch", "Cannot switch branch", (run) => run(["checkout", "--track", ref]), cx);
  },

  createBranch(name, cx) {
    this.runOperation(
      "switch",
      "Cannot create branch",
      async (run) => {
        const valid = await this.gitRaw(["check-ref-format", "--branch", name]);
        if (valid.code !== 0) throw Error(`“${name}” isn't a valid branch name.`);
        return run(["checkout", "-b", name]);
      },
      cx,
    );
  },

  // Enter in the box: the first match is switched to, and with no match the text names
  // a new branch.
  branchEnter(cx) {
    const text = this.branchFilter.value().trim();
    if (!text) return;
    const { locals, remotes } = this.matchingBranches();
    if (locals[0]) return this.switchBranch(locals[0].name, cx);
    if (remotes[0]) return this.switchRemote(remotes[0].ref, cx);
    this.createBranch(text, cx);
  },

  matchingBranches() {
    const text = (this.branchFilter?.value() ?? "").trim().toLowerCase();
    const has = (name) => !text || name.toLowerCase().includes(text);
    return {
      locals: (this.branches?.locals ?? []).filter((b) => has(b.name)),
      remotes: (this.branches?.remotes ?? []).filter((r) => has(r.ref)),
    };
  },
};
