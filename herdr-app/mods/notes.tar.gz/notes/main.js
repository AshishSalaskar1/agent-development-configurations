// Notes: plain-text notes as cards, like Google Keep. Click "Take a note…" to write one,
// click a card to edit it, pin to float it to the top, pick a colour. Notes are kept in
// data/notes/notes.json in Herdr's home, outside mods/ so saving never reloads the mod.
// Notes are Markdown-lite: # headings, **bold**, "- " bullets and "- [ ]" / "- [x]" tasks.
//
// The editor is line by line: each line is its own input, the line you're on shows its raw
// markdown, and every other line is drawn rendered. Herdr's text boxes can't style text
// in place, so this is how typing and the rendered note share one view.
import { View, div, svg } from "gpui-kit";
import { h_flex, v_flex, Input, InputState } from "gpui-base";
import { appHome, checking, exec, readTextFile, theme, writeTextFile } from "herdr";

const DIR = "data/notes";
const FILE = "notes.json";
const PREVIEW_LINES = 14;

// Keep's dark colours: a muted tint behind the text. The first entry is "no colour".
const COLORS = [
  { id: null, name: "Default" },
  { id: "red", name: "Red", bg: "#5c2b29" },
  { id: "yellow", name: "Yellow", bg: "#635d19" },
  { id: "green", name: "Green", bg: "#345920" },
  { id: "teal", name: "Teal", bg: "#16504b" },
  { id: "blue", name: "Blue", bg: "#1e3a5f" },
  { id: "purple", name: "Purple", bg: "#42275e" },
];
const tint = (id) => COLORS.find((c) => c.id === id)?.bg ?? null;

const newId = () => `n${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
const icon = (name, size, color) => svg(`mods/notes/${name}.svg`).size(size).flex_none().text_color(color);

const HEADING = { 1: 17, 2: 15, 3: 13.5 };
const LIST = /^(\s*)([-*])\s+(\[[ xX]\]\s+)?/;
const FOCUS_DELAY = 50;

// One line of text with **bold** runs. Split into words so a long line wraps between them.
function inline(text, { size, color, weight = null, boldColor }) {
  const row = h_flex().w_full().min_w(0).flex_wrap().items_baseline();
  text.split(/(\*\*[^*]+\*\*)/).forEach((part) => {
    const bold = part.length > 4 && part.startsWith("**") && part.endsWith("**");
    const body = bold ? part.slice(2, -2) : part;
    for (const word of body.split(/(\s+)/)) {
      if (!word) continue;
      const el = div().flex_none().whitespace_nowrap().text_size(size).text_color(bold ? boldColor : color).child(word);
      if (bold || weight === "semibold") el.font_semibold();
      row.child(el);
    }
  });
  return row;
}

export default class Notes extends View {
  init(_props, cx) {
    this.notes = [];
    this.editing = null; // { id, isNew, pinned, color }
    this.pressedInEditor = false; // a press began in the editor, so the click that ends it isn't "outside"
    this.showColors = false; // the colour row opens from the palette button
    this.lines = []; // the editor's lines: { id, state }
    this.cur = 0; // the line being typed on
    this.hover = null;
    this.fileText = null;
    this.chain = Promise.resolve();
    this.path = `${appHome()}/${DIR}/${FILE}`;
    this.titleState = InputState.new({ placeholder: "Title" });
    // Enter in the title drops into the first line.
    this.titleState.on("submit", (_e, cx) => this.focusLine(0, "end", cx));
    if (checking()) return;
    cx.spawn(async (cx) => {
      await exec("mkdir", ["-p", `${appHome()}/${DIR}`], {}).catch(() => null);
      const text = await readTextFile(this.path).catch(() => null);
      this.fileText = text;
      try {
        const saved = JSON.parse(text ?? "{}").notes;
        if (Array.isArray(saved)) this.notes = saved.filter((n) => n && typeof n.id === "string");
      } catch {
        this.notes = [];
      }
      cx.notify();
    });
  }

  // Writes are queued so two quick edits never race; a file changed behind our back is
  // overwritten with what's on screen rather than lost to a stale-snapshot error.
  save() {
    const json = JSON.stringify({ notes: this.notes }, null, 2);
    this.chain = this.chain.then(async () => {
      try {
        await writeTextFile(this.path, json, this.fileText);
      } catch {
        const current = await readTextFile(this.path).catch(() => null);
        await writeTextFile(this.path, json, current).catch(() => {});
      }
      this.fileText = json;
    });
  }

  // ── The line editor ───────────────────────────────────────────────────────

  makeLine(text, placeholder) {
    const line = { id: newId(), state: InputState.new({ value: text, placeholder }) };
    line.state.on("change", (_e, cx) => this.lineChanged(line, cx));
    line.state.on("submit", (_e, cx) => this.lineEnter(line, cx));
    return line;
  }

  setLines(body) {
    for (const l of this.lines) l.state.release();
    const parts = body.split("\n");
    this.lines = parts.map((text, i) => this.makeLine(text, i === 0 ? "Take a note…" : undefined));
  }

  body() {
    return this.lines.map((l) => l.state.value()).join("\n");
  }

  indexOf(line) {
    return this.lines.findIndex((l) => l.id === line.id);
  }

  // Puts the keyboard on a line, the caret at `caret` ("end" or a column). Runs a moment
  // later: the line may only just have become an input.
  focusLine(index, caret, cx) {
    const at = Math.max(0, Math.min(this.lines.length - 1, index));
    this.cur = at;
    cx.notify();
    cx.timer.after(FOCUS_DELAY, () => {
      const l = this.lines[at];
      if (!l) return;
      l.state.focus();
      const length = l.state.value().length;
      const c = caret === "end" ? length : Math.min(caret, length);
      l.state.set_selected_range({ start: c, end: c });
    });
  }

  // A paste can bring newlines into a one-line input: they become lines.
  lineChanged(line, cx) {
    const value = line.state.value();
    if (value.includes("\n")) {
      const i = this.indexOf(line);
      if (i === -1) return;
      const parts = value.replace(/\r/g, "").split("\n");
      line.state.set_value(parts[0]);
      this.lines.splice(i + 1, 0, ...parts.slice(1).map((text) => this.makeLine(text)));
      this.focusLine(i + parts.length - 1, "end", cx);
      return;
    }
    cx.notify();
  }

  // Enter: split the line at the caret. A list item starts the next one the same way; an
  // empty list item ends the list instead.
  lineEnter(line, cx) {
    const i = this.indexOf(line);
    if (i === -1) return;
    const text = line.state.value();
    const caret = Math.max(0, Math.min(text.length, line.state.selected_range().start));
    const before = text.slice(0, caret);
    const after = text.slice(caret);
    const marker = LIST.exec(before);
    if (marker && !before.slice(marker[0].length).trim() && !after.trim()) {
      line.state.set_value("");
      this.focusLine(i, 0, cx);
      return;
    }
    const prefix = marker ? `${marker[1]}${marker[2]} ${marker[3] ? "[ ] " : ""}` : "";
    line.state.set_value(before);
    this.lines.splice(i + 1, 0, this.makeLine(prefix + after));
    this.focusLine(i + 1, prefix.length, cx);
  }

  // Backspace at the start joins the line to the one above, Delete at the end pulls the
  // next one up, and the arrows move between lines.
  lineKey(line, event, cx) {
    const i = this.indexOf(line);
    if (i === -1) return;
    const range = line.state.selected_range();
    const text = line.state.value();
    const plain = range.start === range.end;
    const join = (upper, lower, keep) => {
      const above = this.lines[upper];
      const joinAt = above.state.value().length;
      above.state.set_value(above.state.value() + this.lines[lower].state.value());
      this.lines[lower].state.release();
      this.lines.splice(lower, 1);
      this.focusLine(keep, joinAt, cx);
    };
    switch (event.keystroke) {
      case "backspace":
        if (plain && range.start === 0 && i > 0) {
          join(i - 1, i, i - 1);
          cx.stop_propagation();
        }
        break;
      case "delete":
        if (plain && range.start === text.length && i < this.lines.length - 1) {
          join(i, i + 1, i);
          cx.stop_propagation();
        }
        break;
      case "up":
        if (i > 0) {
          this.focusLine(i - 1, range.start, cx);
          cx.stop_propagation();
        }
        break;
      case "down":
        if (i < this.lines.length - 1) {
          this.focusLine(i + 1, range.start, cx);
          cx.stop_propagation();
        }
        break;
    }
  }

  toggleDraftTask(line, cx) {
    const l = this.lines[line];
    if (!l) return;
    l.state.set_value(l.state.value().replace(/\[( |x|X)\]/, (m) => (m === "[ ]" ? "[x]" : "[ ]")));
    cx.notify();
  }

  // ── Notes ─────────────────────────────────────────────────────────────────

  beginNew(cx) {
    this.finish(cx);
    this.titleState.set_value("");
    this.setLines("");
    this.showColors = false;
    this.editing = { id: newId(), isNew: true, pinned: false, color: null };
    this.focusLine(0, "end", cx);
  }

  openNote(note, cx) {
    if (this.editing?.id === note.id) return;
    this.finish(cx);
    this.titleState.set_value(note.title ?? "");
    this.setLines(note.body ?? "");
    this.showColors = false;
    this.editing = { id: note.id, isNew: false, pinned: Boolean(note.pinned), color: note.color ?? null };
    this.focusLine(this.lines.length - 1, "end", cx);
  }

  // Keeps what's in the editor. A note left empty is dropped.
  finish(cx) {
    const edit = this.editing;
    if (!edit) return;
    const title = this.titleState.value().trim();
    const body = this.body().replace(/\s+$/, "");
    this.editing = null;
    for (const l of this.lines) l.state.release();
    this.lines = [];
    const rest = this.notes.filter((n) => n.id !== edit.id);
    if (!title && !body) this.notes = rest;
    else {
      const note = { id: edit.id, title, body, pinned: edit.pinned, color: edit.color, at: Date.now() };
      this.notes = edit.isNew ? [note, ...rest] : this.notes.map((n) => (n.id === edit.id ? note : n));
    }
    this.save();
    cx?.notify();
  }

  remove(id, cx) {
    if (this.editing?.id === id) {
      this.editing = null;
      for (const l of this.lines) l.state.release();
      this.lines = [];
    }
    this.notes = this.notes.filter((n) => n.id !== id);
    this.save();
    cx.notify();
  }

  togglePin(id, cx) {
    this.notes = this.notes.map((n) => (n.id === id ? { ...n, pinned: !n.pinned } : n));
    this.save();
    cx.notify();
  }

  // Ticks or unticks the task on one line of a note, straight in its text.
  toggleTask(id, line, cx) {
    this.notes = this.notes.map((n) => {
      if (n.id !== id) return n;
      const lines = n.body.split("\n");
      lines[line] = lines[line].replace(/\[( |x|X)\]/, (m) => (m === "[ ]" ? "[x]" : "[ ]"));
      return { ...n, body: lines.join("\n") };
    });
    this.save();
    cx.notify();
  }

  // ── Drawing ───────────────────────────────────────────────────────────────

  smallButton(t, id, name, tip, onClick, active = false) {
    return div()
      .id(id)
      .size(24)
      .flex_none()
      .flex()
      .items_center()
      .justify_center()
      .rounded(6)
      .cursor_pointer()
      .tooltip(tip)
      .hover((s) => s.bg(t.hover))
      .on_mouse_down("left", (_e, cx) => cx.stop_propagation())
      .on_click((_e, cx) => {
        cx.stop_propagation();
        onClick(cx);
      })
      .child(icon(name, 14, active ? t.accent : t.muted));
  }

  // One line of a note, rendered: a heading, task, bullet or plain text. `tick` makes
  // tasks clickable.
  mdLine(line, i, t, tick) {
    const head = /^(#{1,3})\s+(.*)$/.exec(line);
    if (head)
      return inline(head[2], { size: HEADING[head[1].length], color: t.foreground, boldColor: t.foreground, weight: "semibold" });
    const task = /^(\s*)[-*]\s+\[( |x|X)\]\s?(.*)$/.exec(line);
    if (task) {
      const done = task[2] !== " ";
      const box = div()
        .id(`todo-task-${tick?.id}-${i}`)
        .size(14)
        .flex_none()
        .mt(2)
        .flex()
        .items_center()
        .justify_center()
        .rounded(3)
        .border_1()
        .border_color(done ? t.accent : t.muted)
        .when(done, (el) => el.bg(t.accent).child(div().text_size(10).font_bold().text_color(t.accent_foreground).child("✓")));
      if (tick)
        box
          .cursor_pointer()
          .on_mouse_down("left", (_e, cx) => cx.stop_propagation())
          .on_click((_e, cx) => {
            cx.stop_propagation();
            if (tick.live) this.toggleDraftTask(i, cx);
            else this.toggleTask(tick.id, i, cx);
          });
      return h_flex()
        .w_full()
        .min_w(0)
        .gap(8)
        .items_start()
        .pl(task[1].length * 6)
        .child(box)
        .child(div().flex_1().min_w(0).child(inline(task[3], { size: 12.5, color: done ? t.dim : t.foreground, boldColor: done ? t.dim : t.foreground })));
    }
    const bullet = /^(\s*)[-*]\s+(.*)$/.exec(line);
    if (bullet)
      return h_flex()
        .w_full()
        .min_w(0)
        .gap(8)
        .items_start()
        .pl(bullet[1].length * 6)
        .child(div().w(14).flex_none().text_size(12.5).text_color(t.muted).text_center().child("•"))
        .child(div().flex_1().min_w(0).child(inline(bullet[2], { size: 12.5, color: t.foreground, boldColor: t.foreground })));
    return inline(line, { size: 12.5, color: t.foreground, boldColor: t.foreground });
  }

  // A note's body for a card.
  markdown(body, t, tick) {
    return body.split("\n").map((line, i) => (line.trim() ? this.mdLine(line, i, t, tick) : div().h(6)));
  }

  // The editor's lines: the one being typed on is an input, the rest are drawn rendered.
  editorLines(t) {
    const only = this.lines.length === 1;
    return this.lines.map((line, i) => {
      if (i === this.cur)
        return div()
          .w_full()
          .on_key_down((event, cx) => this.lineKey(line, event, cx))
          .child(
            Input.new(line.state)
              .id(`todo-line-${line.id}`)
              .w_full()
              .h(26)
              .px(6)
              .rounded(5)
              .border_1()
              .border_color("#00000000")
              .bg("#ffffff12")
              .text_size(12.5)
              .text_color(t.foreground),
          );
      const text = line.state.value();
      return div()
        .id(`todo-line-r-${line.id}`)
        .w_full()
        .min_h(26)
        .px(7)
        .py(3)
        .rounded(5)
        .cursor_text()
        .hover((s) => s.bg("#ffffff0a"))
        .on_click((_e, cx) => this.focusLine(i, "end", cx))
        .child(
          text.trim()
            ? this.mdLine(text, i, t, { id: this.editing?.id, live: true })
            : only
              ? div().text_size(12.5).text_color(t.dim).child("Take a note…")
              : div().h(18),
        );
    });
  }

  card(n, t) {
    const hovered = this.hover === n.id;
    const bg = tint(n.color) ?? t.surface;
    const lines = n.body.split("\n");
    const cut = lines.length > PREVIEW_LINES;
    return v_flex()
      .id(`todo-card-${n.id}`)
      .relative()
      .w_full()
      .min_w(0)
      .p(12)
      .gap(5)
      .rounded(10)
      .border_1()
      .border_color(this.editing?.id === n.id ? t.accent : n.color ? "#ffffff1f" : t.border)
      .bg(bg)
      .cursor_pointer()
      .hover((s) => s.border_color(t.input))
      .on_hover((over, cx) => {
        if (over) this.hover = n.id;
        else if (this.hover === n.id) this.hover = null;
        cx.notify();
      })
      .on_click((_e, cx) => {
        // A card takes its own click: opening it must not also count as "outside".
        cx.stop_propagation();
        this.openNote(n, cx);
      })
      .when(Boolean(n.title), (el) =>
        el.child(div().w_full().min_w(0).pr(48).text_size(14).font_semibold().text_color(t.foreground).child(n.title)),
      )
      .children(this.markdown(lines.slice(0, PREVIEW_LINES).join("\n"), t, { id: n.id }))
      .when(cut, (el) => el.child(div().text_size(12).text_color(t.dim).child("…")))
      .when(n.pinned && !hovered, (el) =>
        el.child(div().absolute().top(10).right(10).child(icon("pin", 12, t.muted))),
      )
      .when(hovered, (el) =>
        el.child(
          h_flex()
            .absolute()
            .top(6)
            .right(6)
            .gap(1)
            .p(1)
            .rounded(7)
            .bg(`${bg.slice(0, 7)}EE`)
            .child(this.smallButton(t, `todo-pin-${n.id}`, "pin", n.pinned ? "Unpin" : "Pin", (cx) => this.togglePin(n.id, cx), n.pinned))
            .child(this.smallButton(t, `todo-del-${n.id}`, "trash", "Delete", (cx) => this.remove(n.id, cx))),
        ),
      );
  }

  section(label, list, t) {
    return v_flex()
      .gap(6)
      .w_full()
      .when(Boolean(label), (el) =>
        el.child(div().px(2).text_size(10.5).font_medium().text_color(t.dim).child(label)),
      )
      .child(v_flex().w_full().gap(10).children(list.map((n) => this.card(n, t))));
  }

  swatches(t) {
    return h_flex()
      .gap(6)
      .items_center()
      .children(
        COLORS.map((c) => {
          const on = (this.editing?.color ?? null) === c.id;
          return div()
            .id(`todo-color-${c.id ?? "none"}`)
            .size(18)
            .flex_none()
            .rounded(9)
            .border_2()
            .border_color(on ? t.foreground : c.bg ? "#ffffff2e" : t.border)
            .bg(c.bg ?? t.surface)
            .cursor_pointer()
            .tooltip(c.name)
            .on_click((_e, cx) => {
              this.editing = { ...this.editing, color: c.id };
              cx.notify();
            });
        }),
      );
  }

  composer(t) {
    const edit = this.editing;
    if (!edit)
      return div()
        .id("todo-compose")
        .w_full()
        .h(40)
        .flex_none()
        .px(12)
        .flex()
        .items_center()
        .rounded(10)
        .border_1()
        .border_color(t.border)
        .bg(t.input)
        .text_size(13)
        .text_color(t.dim)
        .cursor_pointer()
        .hover((s) => s.border_color(t.muted))
        .on_click((_e, cx) => this.beginNew(cx))
        .child("Take a note…");
    const bg = tint(edit.color) ?? t.surface;
    return v_flex()
      .id("todo-editor")
      .w_full()
      .flex_none()
      .p(8)
      .gap(6)
      .rounded(10)
      .border_1()
      .border_color(t.accent)
      .bg(bg)
      // A click inside the editor stays inside it; one anywhere else in the panel reaches
      // the panel's own handler, which closes the note. A press that starts here and ends
      // outside (selecting text) is still not an outside click.
      .on_mouse_down("left", () => {
        this.pressedInEditor = true;
      })
      .on_click((_e, cx) => {
        this.pressedInEditor = false;
        cx.stop_propagation();
      })
      .child(
        Input.new(this.titleState)
          .id("todo-title")
          .w_full()
          .h(28)
          .px(8)
          .rounded(6)
          .text_size(14)
          .font_semibold()
          .text_color(t.foreground),
      )
      .child(
        v_flex()
          .id("todo-lines")
          .w_full()
          .min_h(120)
          .py(4)
          .gap(1)
          .rounded(6)
          .bg("#00000026")
          .children(this.editorLines(t))
          // The empty space under the last line takes a click as "type at the end".
          .child(div().id("todo-lines-end").flex_1().min_h(20).cursor_text().on_click((_e, cx) => this.focusLine(this.lines.length - 1, "end", cx))),
      )
      .when(this.showColors, (el) => el.child(this.swatches(t)))
      .child(
        h_flex()
          .gap(2)
          .items_center()
          .child(
            this.smallButton(t, "todo-edit-pin", "pin", edit.pinned ? "Unpin" : "Pin", (cx) => {
              this.editing = { ...this.editing, pinned: !this.editing.pinned };
              cx.notify();
            }, edit.pinned),
          )
          .child(
            this.smallButton(t, "todo-edit-colors", "palette", "Colour", (cx) => {
              this.showColors = !this.showColors;
              cx.notify();
            }, this.showColors || Boolean(edit.color)),
          )
          .when(!edit.isNew, (el) =>
            el.child(this.smallButton(t, "todo-edit-del", "trash", "Delete", (cx) => this.remove(edit.id, cx))),
          )
          .child(div().flex_1())
          .child(
            div()
              .id("todo-done")
              .h(26)
              .px(12)
              .flex()
              .items_center()
              .rounded(6)
              .text_size(12)
              .font_medium()
              .cursor_pointer()
              .bg(t.solid)
              .text_color(t.solid_foreground)
              .on_click((_e, cx) => this.finish(cx))
              .child("Done"),
          ),
      );
  }

  render() {
    const t = theme();
    // The note in the editor is shown there, not twice.
    const shown = this.notes.filter((n) => n.id !== this.editing?.id);
    const pinned = shown.filter((n) => n.pinned);
    const others = shown.filter((n) => !n.pinned);
    return v_flex()
      .id("notes-pane")
      .size_full()
      .min_h(0)
      .rounded(10)
      .border_1()
      .border_color(t.border)
      .bg(t.chrome)
      .text_color(t.foreground)
      .overflow_hidden()
      // A click anywhere in the panel that nothing else took (the header, the gaps, the empty
      // space under the cards) ends the note being edited, and keeps it.
      .on_click((_e, cx) => {
        if (this.pressedInEditor) {
          this.pressedInEditor = false;
          return;
        }
        if (this.editing) this.finish(cx);
      })
      .child(
        h_flex()
          .h(42)
          .flex_none()
          .px(14)
          .gap(8)
          .items_center()
          .border_b(1)
          .border_color(t.border)
          .child(icon("icon", 15, t.muted))
          .child(div().text_size(13).font_semibold().child("Notes"))
          .child(
            div()
              .px(6)
              .py(1)
              .rounded(4)
              .border_1()
              .border_color(t.border)
              .text_size(10)
              .text_color(t.muted)
              .child(String(this.notes.length)),
          )
          .child(div().flex_1())
          .child(this.smallButton(t, "todo-add", "plus", "New note", (cx) => this.beginNew(cx))),
      )
      .child(
        v_flex()
          .id("todo-scroll")
          .flex_1()
          .min_h(0)
          .p(10)
          .gap(12)
          .overflow_y_scrollbar()
          .child(this.composer(t))
          .when(!shown.length && !this.editing, (el) =>
            el.child(div().w_full().pt(24).text_center().text_size(12).text_color(t.dim).child("Notes you add show up here.")),
          )
          .when(pinned.length > 0, (el) => el.child(this.section(others.length ? "PINNED" : null, pinned, t)))
          .when(others.length > 0, (el) => el.child(this.section(pinned.length ? "OTHERS" : null, others, t))),
      );
  }
}
